
import java.util.*;

/**
 * 
 */
public interface NodeInterface {

   
    public void transCmd(String type, String cmd);

}