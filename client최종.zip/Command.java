
import java.util.*;

/**
 * 
 */
public interface Command {

    public void start();

}