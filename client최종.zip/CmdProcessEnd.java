
public class CmdProcessEnd implements Command {

	@Override
	public void start() {
		// TODO Auto-generated method stub
		System.exit(0);
	}

}
