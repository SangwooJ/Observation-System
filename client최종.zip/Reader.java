
import java.util.*;

/**
 * 
 */
public interface Reader {

    public void readPL();

}